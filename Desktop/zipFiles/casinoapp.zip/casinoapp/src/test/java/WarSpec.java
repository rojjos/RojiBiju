/**
 * Created by rogi on 1/30/16.
 */
public class WarSpec {
}
