/**
 * Created by rogi on 1/29/16.
 */
public class BlackJack {



 int drawCard(){
  return 0;
 };

 int checkResult(){
  return 0;
 };

 String cardTransposer(int[] playersHand){
  return null;
 };

 private void hitOrStay(){


    }

    private int tallyHand(){

        return 0;
    }

    private boolean checkForBlackJack(int handsValueBJ)
    {

    return false;
    }

    private boolean checkForBeatDealer(int dealerHand){

      return false;
    }

    private boolean checkForBust(int handValue){

      return false;

    }

    BlackJack(String gameName, Player player){

    }

    //BlackJack(String Player){

    //}

}
