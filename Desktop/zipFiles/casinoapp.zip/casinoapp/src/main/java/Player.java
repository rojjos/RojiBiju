import java.util.Scanner;

/**
 * Created by rogi on 1/29/16.
 */
public class Player {
 protected int[] cards[];
 protected Scanner scanner = new Scanner(System.in);
 protected String name = scanner.nextLine(); //this name goes to Casino

}
