/**
 * Created by rogi on 1/29/16.
 */
public class War extends Game implements CardGame {

    private void goToWar(){


    }

    War(String gameName, Player player){

        this.gameType = gameName;
        gamePlayers.add(player);
        gamePlayers.add(new Player());
    }


    int drawCard(){
        //Deck deck = new Deck();
         for (int i=0; i < deck.length;i++ ){
             for (int j=  deck[i]){

         }



          /*  DrawCard() {
                .shuffle(c);
            }
            String draw() {
                String s=c.get(0);
                c.remove(s);
                return s;
            }
            final List<String> c=new ArrayList<String>(Arrays.asList(cards));
            static String cards[]={""};
        }
        public class Gd40356 {
            static void run() {
                Deck deck=new Deck();
                System.out.print("drawing: ");
                for(int i=0;i<deck.cards.length;i++)
                    System.out.print(deck.draw()+' ');
                System.out.println();
            }
            public static void main(String[] args) {
                run();
                run();
            }*/

        return 0;
    };

    int checkResult(){
        return 0;
    };

    String cardTransposer(int[] playersHand){
        return null;
    };

}
