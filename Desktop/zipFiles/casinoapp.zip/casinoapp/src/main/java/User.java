/**
 * Created by rogi on 1/29/16.
 */
public class User extends Player {
    private String myGame;
    private int wallet =500;


    private void tapMAC(int cashMoney){
        wallet += cashMoney;

    }
}
