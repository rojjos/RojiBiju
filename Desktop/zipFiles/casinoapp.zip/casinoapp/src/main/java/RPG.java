/**
 * Created by rogi on 1/29/16.
 */
public class RPG extends Game {

    private int[] healthPointArray[];


    RPG(String name, Player player){


    }
    private void attack(int ){


    }

    private void defend(){

    }

    private void getSpell(){


    }

    private void display(){

    }

    private void display(String ) {


    }

    private void display(int){

    }

}
