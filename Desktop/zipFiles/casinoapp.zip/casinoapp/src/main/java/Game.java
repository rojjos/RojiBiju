import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * Created by rogi on 1/29/16.
 */
public class Game {

    protected Scanner scanner = new Scanner(System.in);

    protected String gameType = scanner.nextLine();

    protected ArrayList<Player> gamePlayers;

    protected Random rand;



    protected void display(){


    }

    protected void setupGame(){


    }

    protected void promptGameChange(){


    }

    protected void checkWallet(){


    }


}
