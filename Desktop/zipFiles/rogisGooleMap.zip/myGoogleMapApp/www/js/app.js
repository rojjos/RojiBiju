// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
var app = angular.module('app', ['ionic'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
});
app.controller("MapController", function($scope){
  google.maps.event.addDomListener(window, "load", function(){

var myLatlng = new google.maps.LatLng(37.3000,-120.4033);

var mapOptions={
    center : myLatlng,
    zoom: 16,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };

    var map = new google.maps.Map(document.getElementById("map"),mapOptions);
    $scope.map=map;

var marker = new google.maps.Marker({
    position: myLatlng,
    map: $scope.map,
    animation: google.maps.Animation.DROP,
    title: 'Hello World!',

    });

var infoWindow = new google.maps.InfoWindow({
      content: "Here I am!"
    });

    google.maps.event.addListener(marker, 'click', function () {
      infoWindow.open($scope.map, marker);
    });

 

  });
});


